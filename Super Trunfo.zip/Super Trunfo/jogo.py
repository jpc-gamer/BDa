#Julia Peres Cardoso e Hellen Novi Salvador

import random

gabarito = ["Nome", "Velocidade", "Tanque", "Ano"]


def embaralhar_cartas(baralho):
    random.shuffle(baralho)


def dividir_cartas(baralho, jogador1, jogador2):

    for carta in baralho:

        if len(jogador1) <= len(jogador2):
            jogador1.append(carta)

        else:
            jogador2.append(carta)


def mostrar_carta(carta):

    print("\nCarta:")

    for i in range(len(gabarito)):
        print(i, "-", gabarito[i], ":", carta[i])


def verificar_vencedor(valor1, valor2):

    if valor1 > valor2:
        return 1

    elif valor2 > valor1:
        return 2

    else:
        return 0


def jogar(opcao):

    baralho = [
        ["Ferrari F40", 324, 120, 1987],
        ["Toyota Yaris", 175, 36, 2024],
        ["Audi R8", 330, 83, 2021],
        ["Bugatti Chiron", 420, 100, 2016],
        ["Porsche 911", 310, 64, 2023],
        ["McLaren P1", 350, 72, 2013],
        ["BYD Song", 170, 60, 2023],
        ["Lamborghini", 350, 90, 2011]
    ]

    jogador1 = []
    jogador2 = []
    monte = []

    embaralhar_cartas(baralho)

    dividir_cartas(baralho, jogador1, jogador2)

    vez = 1

    while len(jogador1) > 0 and len(jogador2) > 0:

        print("\n------------------")
        print("Jogador 1:", len(jogador1), "cartas")
        print("Jogador 2:", len(jogador2), "cartas")

        carta1 = jogador1[0]
        carta2 = jogador2[0]

        if vez == 1:

            print("\nVEZ DO JOGADOR 1")

            mostrar_carta(carta1)

            atributo = int(input("\nDigite atributo (1 a 3): "))

            while atributo < 1 or atributo > 3:
                atributo = int(input("Digite um atributo válido: "))

        else:

            if opcao == 1:

                atributo = random.randint(1, 3)

                print("\nCOMPUTADOR ESCOLHEU:",
                      gabarito[atributo])

            else:

                print("\nVEZ DO JOGADOR 2")

                mostrar_carta(carta2)

                atributo = int(input("\nDigite atributo (1 a 3): "))

                while atributo < 1 or atributo > 3:
                    atributo = int(input("Digite um atributo válido: "))

        valor1 = carta1[atributo]
        valor2 = carta2[atributo]

        print("\nJogador 1:", valor1)
        print("Jogador 2:", valor2)

        vencedor = verificar_vencedor(valor1, valor2)

        if vencedor == 1:

            print("\nJOGADOR 1 VENCEU A RODADA")

            jogador1.append(carta1)
            jogador1.append(carta2)

            for carta in monte:
                jogador1.append(carta)

            monte.clear()

            jogador1.pop(0)
            jogador2.pop(0)

            vez = 1

        elif vencedor == 2:

            print("\nJOGADOR 2 VENCEU A RODADA")

            jogador2.append(carta1)
            jogador2.append(carta2)

            for carta in monte:
                jogador2.append(carta)

            monte.clear()

            jogador1.pop(0)
            jogador2.pop(0)

            vez = 2

        else:

            print("\nEMPATE")

            monte.append(carta1)
            monte.append(carta2)

            jogador1.pop(0)
            jogador2.pop(0)

            print("Cartas acumuladas no monte:",
                  len(monte))


    print("\n===== FIM DE JOGO =====")

    if len(jogador1) > 0:
        print("JOGADOR 1 É O VENCEDOR")

    else:
        print("JOGADOR 2 É O VENCEDOR")


def menu():

    while True:

        print("\n===== SUPER TRUNFO =====")
        print("1 - Single Player")
        print("2 - Multiplayer")
        print("3 - Sair")

        opcao = int(input("\nEscolha: "))

        if opcao == 3:

            print("\nFim do jogo")
            break

        elif opcao == 1 or opcao == 2:

            jogar(opcao)

        else:

            print("\nOpção inválida")


menu()
